package com.sda.javagda22.Pjeski;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PjeskiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PjeskiApplication.class, args);
	}

}
